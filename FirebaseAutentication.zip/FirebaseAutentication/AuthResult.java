/**
 * @Author gabesouza007amor@gmail.com 
*/
public class AuthResult{ 
   FirebaseUser user;
   String idToken;
   String refreshToken;
   public AuthResult(FirebaseUser u,String id,String refresh){
       this.user = u;
       this.idToken =id;
       this.refreshToken = refresh;
   }

   public String getIdToken(){
       return idToken;
   }
   public String getRefreshToken(){
       return refreshToken;
   }
   public FirebaseUser getUser(){
       return user;
   }
}
