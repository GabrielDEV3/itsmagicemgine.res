/** @Author gabesouza007amor@gmail.com */

//
import org.json.*;
import java.util.concurrent.Callable;

public class FirebaseAuth implements FirebaseAuthApi {

  private static ProjectFile file;

  String api;
  static FirebaseUser currentUser;

  public static void setAPIFile(ProjectFile pf) {
    file = pf;
  }

  public FirebaseAuth(String apikey) {
    this.api = apikey;
  }

  public static FirebaseAuth getInstance() {
    try {
      BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()));
      StringBuilder response = new StringBuilder();
      String line;
      while ((line = br.readLine()) != null) {
        response.append(line);
      }
      JSONObject jsonObject = new JSONObject(response.toString());
      JSONArray clients = jsonObject.getJSONArray("client");
      String currentKey = "";
      for (int i = 0; i < clients.length(); i++) {
        JSONObject client = clients.getJSONObject(i);
        JSONArray apiKeyArray = client.getJSONArray("api_key");
        JSONObject apiKey = apiKeyArray.getJSONObject(0);
        currentKey = apiKey.getString("current_key");
      }
      FirebaseAuth fb = new FirebaseAuth(currentKey);
      br.close();
      return fb;
    } catch (JSONException e) {
      Console.log(e);
      return null;
    } catch (IOException e) {
      Console.log(e);
      return null;
    }
  }

  public Task<AuthResult> createUserWithEmailAndPassword(final String email, final String pass) {
    return Tasks.call(
        new Callable<AuthResult>() {
          public AuthResult call() throws Exception {
            try {
              URL url = new URL("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + api);
              HttpURLConnection connection = (HttpURLConnection) url.openConnection();
              connection.setRequestMethod("POST");
              connection.setRequestProperty("Content-Type", "application/json");
              connection.setDoOutput(true);

              // Corpo da requisição - dados para criar a conta
              JSONObject requestBody = new JSONObject();
              requestBody.put("email", email);
              requestBody.put("password", pass);
              requestBody.put("displayName", "");
              requestBody.put("returnSecureToken", true);

              // Enviando os dados para o servidor
              OutputStream out = connection.getOutputStream();
              out.write(requestBody.toString().getBytes());
              out.flush();
              out.close();

              int responseCode = connection.getResponseCode();
              if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                  response.append(line);
                }
                reader.close();

                JSONObject object = new JSONObject(response.toString());
                String uid = object.getString("localId");
                String name = object.getString("displayName");
                String emailUser = object.getString("email");
                String idToken = object.getString("idToken");
                String refreshToken = object.getString("refreshToken");
                
                currentUser = new FirebaseUser(api, idToken, uid, emailUser, name);
                connection.disconnect();
                return new AuthResult(currentUser, idToken, refreshToken);
              } else {
                connection.disconnect();
                throw new Exception("Falha ao criar " + responseCode + "\n URL:" + url.toString());
              }
            } catch (Exception e) {
              throw e;
            }
          }
        });
  }

  public Task<AuthResult> signInWithEmailAndPassword(final String email, final String pass) {
    return Tasks.call(
        new Callable<AuthResult>() {
          public AuthResult call() throws Exception {
            try {
              URL url = new URL("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + api);
              HttpURLConnection connection = (HttpURLConnection) url.openConnection();
              connection.setRequestMethod("POST");
              connection.setRequestProperty("Content-Type", "application/json");
              connection.setDoOutput(true);

              JSONObject requestBody = new JSONObject();
              requestBody.put("email", email);
              requestBody.put("password", pass);
              requestBody.put("returnSecureToken", true);

              OutputStream out = connection.getOutputStream();
              out.write(requestBody.toString().getBytes());
              out.flush();
              out.close();

              int responseCode = connection.getResponseCode();
              final AuthResult res;
              if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                  response.append(line);
                }
                reader.close();
                
                JSONObject object = new JSONObject(response.toString());
                String uid = object.getString("localId");
                String name = object.getString("displayName");
                String emailUser = object.getString("email");
                String idToken = object.getString("idToken");
                String refreshToken = object.getString("refreshToken");

                currentUser = new FirebaseUser(api, idToken, uid, emailUser, name);
                connection.disconnect();
                return new AuthResult(currentUser, idToken, refreshToken);

              } else {
                connection.disconnect();
                throw new Exception("Falha ao entrar " + responseCode + "\n URL:" + url.toString());
              }
            } catch (Exception e) {
              throw e;
            }
          }
        });
  }

  public FirebaseUser getCurrentUser() {
    return currentUser;
  }

  public void signInWithCredential(AuthCredential credential) throws Exception{
    throw new Exception("No action function, under develop");
  }

  public void signOut() throws Exception {
    currentUser = null;
    throw new Exception("No action function, under develop");
  }

  public void sendPasswordResetEmail(String email) throws Exception{
    throw new Exception("No action function, under develop");
  }

  public void confirmPasswordReset(String code, String newPassword) throws Exception{
    throw new Exception("No action function, under develop");
  }

  public void applyActionCode(String code) throws Exception{
  throw new Exception("No action function, under develop");
  }

  public void fetchSignInMethodsForEmail(String email) throws Exception{
    throw new Exception("No action function, under develop");
  }

  public Task<AuthResult> signInAnonymously() throws Exception{
    throw new Exception("No action function, under develop");
  }

/*  public void startActivityForSignInWithProvider(Activity activity, FederatedAuthProvider provider) {
    Console.log("No action function, under develop");
  }
*/
  public void signInWithCustomToken(String token) throws Exception{
    throw new Exception("No action function, under develop");
    
  } 
}
