/**
 * @Author gabesouza007amor@gmail.com 
*/
public interface FirebaseAuthApi{ 
   Task<AuthResult> createUserWithEmailAndPassword(String email, String pass);
   Task<AuthResult> signInWithEmailAndPassword(String email,String pass);
}
