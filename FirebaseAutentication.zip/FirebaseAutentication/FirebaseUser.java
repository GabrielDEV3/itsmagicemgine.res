/** @Author gabesouza007amor@gmail.com */
import org.json.*;
import java.util.concurrent.Callable;

public class FirebaseUser {
  String api;
  String token;
  String uid;
  String email;
  String name;

  public FirebaseUser(String a, String idToken, String uid, String email, String name) {
    this.api = a;
    this.token = idToken;
    this.uid = uid;
    this.email = email;
    this.name = name;
  }

  public String getUid() {
    return uid;
  }

  public String getDisplayName() {
    return name;
  }

  public String getEmail() {
    return email;
  }

  public Task<Void> updateProfile(final UserProfileChangeRequest request) {
    return Tasks.call(
        new Callable<Void>() {
          public Void call() throws Exception {
            try {
              URL url = new URL("https://identitytoolkit.googleapis.com/v1/accounts:update?key=" + api);
              HttpURLConnection connection = (HttpURLConnection) url.openConnection();
              connection.setRequestMethod("POST");
              connection.setRequestProperty("Content-Type", "application/json");
              connection.setDoOutput(true);

              JSONObject object = new JSONObject();
              object.put("idToken", token);
              object.put("displayName", request.getDisplayName());
              object.put("returnSecureToken", true);

              OutputStream out = connection.getOutputStream();
              out.write(object.toString().getBytes());
              out.flush();
              out.close();

              StringBuilder response = new StringBuilder();
              BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
              String line;           
              while ((line = br.readLine()) != null) {
                response.append(line);
              }
              JSONObject objectRes = new JSONObject(response.toString());
              uid = objectRes.getString("localId");
              name = objectRes.getString("displayName");
              email = objectRes.getString("email");
              FirebaseUser user = new FirebaseUser(api,token,uid,email,name);
              FirebaseUserUtil util = new FirebaseUserUtil();
              util.setFirebaseUser(user);
              return null;
            } catch (Exception e) {
              throw e;
            } 
          }
        });
  }
  private class FirebaseUserUtil {
       public void setFirebaseUser(FirebaseUser fb){
           FirebaseAuth.currentUser = fb;
       }
  }
}
