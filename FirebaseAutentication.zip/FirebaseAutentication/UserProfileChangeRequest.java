public class UserProfileChangeRequest {
  private String displayName;

  private UserProfileChangeRequest(Builder builder) {
    this.displayName = builder.displayName;
  }

  public String getDisplayName() {
    return displayName;
  }
  
  public static class Builder {
    private String displayName;

    public Builder setDisplayName(String displayName) {
      this.displayName = displayName;
      return this;
    }

    public UserProfileChangeRequest build() {
      return new UserProfileChangeRequest(this);
    } 
  }
}