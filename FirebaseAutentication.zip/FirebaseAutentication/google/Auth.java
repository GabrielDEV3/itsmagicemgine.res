/**
 * @Author gabesouza007amor@gmail.com 
*/
public class Auth{ 

   public Auth(){
       // constructor
   }

   public void method(){
       // method
   }
}
