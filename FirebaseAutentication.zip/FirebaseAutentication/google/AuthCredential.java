/**
 * @Author gabesouza007amor@gmail.com 
*/
public class AuthCredential{ 

   public AuthCredential(){
       // constructor
   }

   public void method(){
       // method
   }
}
