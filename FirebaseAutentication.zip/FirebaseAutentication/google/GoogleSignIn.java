/**
 * @Author gabesouza007amor@gmail.com 
*/
public class GoogleSignIn{ 

   public GoogleSignIn(){
       // constructor
   }

   public void method(){
       // method
   }
}
