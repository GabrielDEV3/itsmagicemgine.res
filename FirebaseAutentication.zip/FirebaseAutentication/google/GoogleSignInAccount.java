/**
 * @Author gabesouza007amor@gmail.com 
*/
public class GoogleSignInAccount{ 

   public GoogleSignInAccount(){
       // constructor
   }

   public void method(){
       // method
   }
}
