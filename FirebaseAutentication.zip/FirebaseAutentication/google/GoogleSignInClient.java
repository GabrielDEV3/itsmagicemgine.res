/**
 * @Author gabesouza007amor@gmail.com 
*/
public class GoogleSignInClient{ 

   public GoogleSignInClient(){
       // constructor
   }

   public void method(){
       // method
   }
}
