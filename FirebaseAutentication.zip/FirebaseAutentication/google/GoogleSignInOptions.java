/**
 * @Author gabesouza007amor@gmail.com 
*/
public class GoogleSignInOptions{ 

   public GoogleSignInOptions(){
       // constructor
   }

   public void method(){
       // method
   }
}
