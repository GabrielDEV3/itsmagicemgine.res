/**google.com**/

import java.util.ArrayList;
import java.util.List;

public class Task<T> {
    private T result;
    private Exception exception;
    private boolean isSuccessful;
    private boolean isComplete;
    private List<OnCompleteListener<T>> completeListeners;
    private List<OnSuccessListener<T>> successListeners;
    private List<OnFailureListener> failureListeners;

    public Task() {
        completeListeners = new ArrayList<OnCompleteListener<T>>();
        successListeners = new ArrayList<OnSuccessListener<T>>();
        failureListeners = new ArrayList<OnFailureListener>();
    }

    public void addOnCompleteListener(OnCompleteListener<T> listener) {
        if (listener != null) {
            completeListeners.add(listener);
            if (isComplete) {
                listener.onComplete(this);
            }
        }
    }

    public void addOnSuccessListener(OnSuccessListener<T> listener) {
        if (listener != null) {
            successListeners.add(listener);
            if (isComplete && isSuccessful) {
                listener.onSuccess(result);
            }
        }
    }

    public void addOnFailureListener(OnFailureListener listener) {
        if (listener != null) {
            failureListeners.add(listener);
            if (isComplete && !isSuccessful) {
                listener.onFailure(exception);
            }
        }
    }

    public boolean isSuccessful() {
        return isSuccessful;
    }

    public boolean isComplete() {
        return isComplete;
    }

    public T getResult() {
        return result;
    }

    public Exception getException() {
        return exception;
    }

    public Task<T> setResult(T result) {
        this.result = result;
        this.isSuccessful = true;
        this.isComplete = true;
        notifyListeners();
        return this;
    }

    public Task<T> setException(Exception exception) {
        this.exception = exception;
        this.isSuccessful = false;
        this.isComplete = true;
        notifyListeners();
        return this;
    }

    private void notifyListeners() {
        for (OnCompleteListener<T> listener : completeListeners) {
            listener.onComplete(this);
        }
        if (isSuccessful) {
            for (OnSuccessListener<T> listener : successListeners) {
                listener.onSuccess(result);
            }
        } else {
            for (OnFailureListener listener : failureListeners) {
                listener.onFailure(exception);
            }
        }
    }
}
