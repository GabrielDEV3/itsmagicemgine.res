
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class Tasks {

    public static <T> Task<T> call(final Callable<T> callable) {
        final TaskCompletionSource<T> tcs = new TaskCompletionSource<T>();

        new Thread(new Runnable() {
            public void run() {
                try {
                    T result = callable.call();
                    tcs.setResult(result);
                } catch (Exception e) {
                    tcs.setException(e);
                }
            }
        }).start();

        return tcs.getTask();
    }

    public static <T> Task<T> forResult(final T result) {
        TaskCompletionSource<T> tcs = new TaskCompletionSource<T>();
        tcs.setResult(result);
        return tcs.getTask();
    }

    public static <T> Task<T> forException(final Exception exception) {
        TaskCompletionSource<T> tcs = new TaskCompletionSource<T>();
        tcs.setException(exception);
        return tcs.getTask();
    }

    public static <T> Task<List<T>> whenAll(final Task<T>... tasks) {
        final TaskCompletionSource<List<T>> tcs = new TaskCompletionSource<List<T>>();
        final int size = tasks.length;
        final Object lock = new Object();
        final List<T> results = new ArrayList<T>(size);
        final AtomicInteger count = new AtomicInteger(size);

        for (int i = 0; i < size; i++) {
            final int index = i;
            tasks[i].addOnCompleteListener(
                new OnCompleteListener<T>() {
                    public void onComplete(Task<T> task) {
                        if (task.isSuccessful()) {
                            synchronized (lock) {
                                results.add(index, task.getResult());
                                if (count.decrementAndGet() == 0) {
                                    tcs.setResult(results);
                                }
                            }
                        } else {
                            tcs.setException(task.getException());
                        }
                    }
                });
        }

        return tcs.getTask();
    }
}
