/**google.com**/
public interface OnCompleteListener<T> {
    void onComplete(Task<T> task);
}
