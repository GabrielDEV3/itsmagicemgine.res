
public interface OnFailureListener {
  void onFailure(Exception exception);
} 