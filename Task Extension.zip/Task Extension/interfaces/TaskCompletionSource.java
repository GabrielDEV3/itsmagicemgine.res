import java.util.concurrent.atomic.AtomicBoolean;

public class TaskCompletionSource<T> {
    private final Task<T> task;
    private final AtomicBoolean completed;

    public TaskCompletionSource() {
        task = new Task<T>();
        completed = new AtomicBoolean(false);
    }

    public Task<T> getTask() {
        return task;
    }

    public void setResult(T result) {
        if (completed.compareAndSet(false, true)) {
            task.setResult(result);
        } else {
            throw new IllegalStateException("Task already completed");
        }
    }

    public void setException(Exception exception) {
        if (completed.compareAndSet(false, true)) {
            task.setException(exception);
        } else {
            throw new IllegalStateException("Task already completed");
        }
    }
}